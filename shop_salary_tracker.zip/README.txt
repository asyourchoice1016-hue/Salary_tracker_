SHOP SALARY TRACKER
Open index.html in a browser. Data is saved locally on the phone/browser.

Features:
- Two people: My Name and Brother
- Daily date, attendance, salary, received/not received
- Automatic daily balance
- Monthly totals, received, balance and owner total balance
- History
- Edit and delete entries
